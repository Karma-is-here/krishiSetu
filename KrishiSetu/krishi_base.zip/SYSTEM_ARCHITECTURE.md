# Agricultural Claim Validation System - Architecture

## 🔥 Core System Principle

This is an **event-driven + state-driven** distributed workflow engine, not just a blockchain integration.

**Key Characteristics:**
- Every action changes system state
- State controls visibility
- Authorities act on claims sequentially or conditionally
- Blockchain stores validated state transitions
- Immutable claim history

---

## 🧠 System Actors

### 1. Farmer
**Can:**
- Create claims
- View claim status and timeline
- View authority decisions
- Receive payout status

**Cannot:**
- Modify claim after submission
- See internal authority discussions

### 2. Insurance Authority (Org1)
**Role:** Primary validator
- View assigned claims
- Review AI evidence
- Actions: APPROVE / REJECT / ESCALATE

### 3. State Authority (Org2)
**Role:** Secondary validator (triggered by policy)
- Field-level verification
- Validate insurance decisions
- Actions: APPROVE / REJECT / ESCALATE

### 4. Central Authority (Org3)
**Role:** Final decision authority
**Activated for:**
- High-risk claims (risk score > 0.7)
- Conflicting approvals between authorities
- Low confidence cases (confidence < 0.6)
- Escalated claims

### 5. Bank (Org4)
**Role:** Payout execution
- Execute approved payouts
- Update payout status

### 6. Audit Authority (Org5)
**Role:** Oversight (read-only)
- View complete transaction history
- No modification rights
- Full system transparency

---

## 🔥 State Machine

### Claim States
```
DRAFT           → Initial state (not used in production)
SUBMITTED       → Farmer submitted claim
AI_ANALYZED     → AI evidence generated
UNDER_REVIEW    → Assigned to authorities
ENDORSED        → Partial approvals received
REJECTED        → Any authority rejected
APPROVED        → All authorities approved
PAYOUT_PENDING  → Approved, awaiting disbursement
PAID            → Payout completed
ESCALATED       → Sent to higher authority
```

### State Flow
```
Farmer submits
    ↓
SUBMITTED
    ↓
AI generates evidence (3 seconds simulation)
    ↓
AI_ANALYZED
    ↓
Policy engine assigns authorities
    ↓
UNDER_REVIEW
    ↓
Authorities validate (APPROVE/REJECT/ESCALATE)
    ↓
APPROVED / REJECTED / ESCALATED
    ↓
If APPROVED → PAYOUT_PENDING
    ↓
Bank disburses
    ↓
PAID
```

---

## 🔥 Policy Engine Logic

### Risk-Based Authority Assignment

**Low Risk (R < 0.4, C > 0.7)**
- Insurance only

**Moderate Risk (0.4 ≤ R ≤ 0.7, C ≥ 0.6)**
- Insurance + State

**High Risk (R > 0.7 OR C < 0.6)**
- Insurance + State + Central

### Authority Assignment Rules
```typescript
IF riskScore < 0.4 AND confidence > 0.7
  → Insurance only

IF riskScore between 0.4-0.7 AND confidence >= 0.6
  → Insurance + State

IF riskScore > 0.7 OR confidence < 0.5
  → Insurance + State + Central
```

---

## 🔥 Veto & Escalation Mechanism

### Authority Actions
1. **APPROVE** - Validates claim
2. **REJECT** - Denies claim (any authority can reject)
3. **ESCALATE** - Send to higher authority

### Veto Logic
- **Any mandatory authority rejects** → Claim status = REJECTED
- **Authority escalates** → Add higher authority, status = ESCALATED

### Conflict Resolution
```
Insurer APPROVES + State REJECTS
  → Automatically escalated to Central Authority
  → Status = ESCALATED
```

---

## 🔥 Visibility Logic

### Farmer View
- All their claims
- Complete timeline
- Authority decisions
- AI evidence and explanation

### Authority View
**Insurance:**
- Only claims where assignedAuthorities includes "insurance"
- Only if they haven't already acted (unless escalated)

**State:**
- Only moderate/high risk claims
- Only claims assigned by policy engine

**Central:**
- High-risk claims (risk > 0.7)
- Escalated claims
- Conflict cases

**Bank:**
- Only PAYOUT_PENDING and PAID claims

**Audit:**
- ALL claims (read-only)
- Complete state history
- All authority endorsements

---

## 🔥 Immutability & State History

### State Transitions
Every state change is recorded:
```typescript
{
  from: 'UNDER_REVIEW',
  to: 'APPROVED',
  timestamp: '2026-05-13T14:30:00Z',
  actor: 'insurance',
  reason: 'High risk score, strong evidence'
}
```

### Authority Endorsements
```typescript
{
  authority: 'insurance',
  action: 'APPROVE',
  timestamp: '2026-05-13T14:30:00Z',
  reason: 'AI risk score 0.78, high confidence',
  confidence: 0.85
}
```

### Blockchain Integration
- Each claim receives a blockchain hash
- Hash represents immutable record on Hyperledger Fabric
- State transitions stored on-chain
- Cannot be modified after submission

---

## 🔥 AI Evidence System

### Input Data
- NDVI (Normalized Difference Vegetation Index)
- Rainfall data
- Soil moisture
- Historical patterns

### Output
```typescript
{
  riskScore: 0.78,        // 0-1 scale
  confidence: 0.85,       // 0-1 scale
  factors: [
    {
      factor: 'NDVI (Vegetation Index)',
      value: 0.35,
      impact: 'negative'
    },
    // ...
  ],
  ndviData: [...],        // Time series
  rainfallData: [...],    // Time series
  soilData: [...]         // Time series
}
```

### Explainability
Every decision includes:
- Risk score breakdown
- Confidence level
- Key contributing factors
- Visual data (graphs)
- Policy rule applied
- Conclusion reasoning

---

## 🔥 Technical Stack (Frontend Simulation)

### Current Implementation
- **Frontend:** React + TypeScript
- **State Management:** React Context API
- **Charts:** Recharts
- **Styling:** Tailwind CSS v4
- **Language:** English + Hindi (i18n)

### Production Stack Recommendation
- **Frontend:** React / Next.js
- **Backend:** Node.js + Express
- **AI Service:** Python FastAPI
- **Blockchain:** Hyperledger Fabric
- **Database:** PostgreSQL (off-chain) + Fabric Ledger (on-chain)
- **Real-time:** Socket.IO / WebSockets

---

## 🔥 Data Architecture

### Off-Chain Database
Store:
- UI data and caching
- User sessions and authentication
- Temporary data

### On-Chain Blockchain
Store:
- Claim hash
- Evidence hash
- Authority approvals (endorsements)
- Final decisions
- State transitions
- Immutable audit trail

---

## 🔥 Security Model

### Role-Based Access Control
- Each authority: separate login
- Separate MSP identity (Hyperledger Fabric)
- Role-based visibility
- Action-based permissions

### Immutability Guarantee
- Claims cannot be edited after submission
- Only state transitions allowed
- All changes recorded with actor + timestamp
- Blockchain provides cryptographic proof

---

## 🔥 Key Differentiators

1. **Policy-Driven Workflow Engine**
   - Dynamic authority assignment
   - Risk-based routing
   - Automated conflict resolution

2. **Complete Explainability**
   - Every decision has reasoning
   - AI evidence transparency
   - Full audit trail

3. **Democratic Governance**
   - Multi-authority validation
   - Veto mechanism
   - Escalation paths

4. **Immutable State Machine**
   - Event-sourcing pattern
   - Complete history
   - Blockchain-secured

5. **Real-Time Updates**
   - Instant status changes
   - Live authority actions
   - Farmer visibility

---

## 🔥 System Flow Example

```
1. Farmer submits claim (Wheat, Drought)
   → State: SUBMITTED

2. AI analyzes in 3 seconds
   → Risk: 0.76, Confidence: 0.84
   → State: AI_ANALYZED

3. Policy engine assigns authorities
   → Risk > 0.7 → Insurance + State + Central
   → State: UNDER_REVIEW

4. Insurance reviews and APPROVES
   → State: ENDORSED

5. State reviews and REJECTS
   → Conflict detected!
   → State: ESCALATED
   → Central added to review

6. Central makes final decision: APPROVE
   → State: APPROVED
   → State: PAYOUT_PENDING (automatic)

7. Bank disburses ₹45,000
   → State: PAID
```

---

## 🔥 Implementation Notes

### Frontend Simulation
This prototype simulates:
- 3-second AI analysis delay
- Real-time state updates
- Authority assignment logic
- Conflict detection
- Blockchain hashing

### Production Considerations
1. Connect to real Hyperledger Fabric network
2. Implement actual AI/ML models
3. Add WebSocket real-time updates
4. Integrate with satellite data APIs
5. Connect to payment gateway
6. Add authentication (Aadhaar, OTP)
7. Implement multi-language support fully
8. Add mobile responsive design

---

**This is not "just blockchain integration"**
**This is a policy-driven distributed workflow engine with complete transparency and explainability.**
