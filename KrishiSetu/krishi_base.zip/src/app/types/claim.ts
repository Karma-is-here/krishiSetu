export type ClaimState =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'AI_ANALYZED'
  | 'UNDER_REVIEW'
  | 'ENDORSED'
  | 'REJECTED'
  | 'APPROVED'
  | 'PAYOUT_PENDING'
  | 'PAID'
  | 'ESCALATED';

export type AuthorityAction = 'APPROVE' | 'REJECT' | 'ESCALATE';

export type AuthorityType = 'insurance' | 'state' | 'central' | 'bank';

export interface StateTransition {
  from: ClaimState;
  to: ClaimState;
  timestamp: string;
  actor: string;
  reason?: string;
}

export interface AuthorityEndorsement {
  authority: AuthorityType;
  action: AuthorityAction;
  timestamp: string;
  reason: string;
  confidence?: number;
}

export interface AIEvidence {
  riskScore: number;
  confidence: number;
  factors: Array<{
    factor: string;
    value: number;
    impact: 'positive' | 'negative';
  }>;
  ndviData: Array<{ month: string; value: number }>;
  rainfallData: Array<{ month: string; value: number }>;
  soilData: Array<{ month: string; value: number }>;
}

export interface Claim {
  id: string;
  farmerId: string;
  farmerName: string;
  cropType: string;
  region: string;
  season: string;
  incidentType: string;
  submittedDate: string;

  // State Management
  currentState: ClaimState;
  stateHistory: StateTransition[];

  // AI Analysis
  aiEvidence?: AIEvidence;

  // Authority Management
  assignedAuthorities: AuthorityType[];
  endorsements: AuthorityEndorsement[];

  // Blockchain Reference
  blockchainHash?: string;

  // Payout
  payoutAmount?: number;
  payoutDate?: string;
}

export interface PolicyRule {
  condition: (evidence: AIEvidence) => boolean;
  authorities: AuthorityType[];
  description: string;
}
