import { createContext, useContext, useState, ReactNode } from 'react';
import {
  Claim,
  ClaimState,
  AuthorityType,
  AuthorityAction,
  StateTransition,
  AuthorityEndorsement,
} from '../types/claim';
import { generateAIEvidence, assignAuthorities } from '../utils/policyEngine';

interface ClaimContextType {
  claims: Claim[];
  submitClaim: (
    farmerId: string,
    farmerName: string,
    cropType: string,
    region: string,
    season: string,
    incidentType: string
  ) => Promise<Claim>;
  processAIAnalysis: (claimId: string) => void;
  submitAuthorityAction: (
    claimId: string,
    authority: AuthorityType,
    action: AuthorityAction,
    reason: string
  ) => void;
  disbursePayout: (claimId: string) => void;
  getClaimById: (claimId: string) => Claim | undefined;
  getClaimsForAuthority: (authority: AuthorityType) => Claim[];
  getClaimsForFarmer: (farmerId: string) => Claim[];
}

const ClaimContext = createContext<ClaimContextType | undefined>(undefined);

export function ClaimProvider({ children }: { children: ReactNode }) {
  const [claims, setClaims] = useState<Claim[]>([
    // Sample claims for demo
    {
      id: 'CLM-2026-001',
      farmerId: 'F-12345',
      farmerName: 'Ramesh Kumar',
      cropType: 'Rice',
      region: 'Maharashtra',
      season: 'Kharif 2026',
      incidentType: 'Drought',
      submittedDate: '2026-03-15',
      currentState: 'APPROVED',
      stateHistory: [
        {
          from: 'DRAFT',
          to: 'SUBMITTED',
          timestamp: '2026-03-15T10:00:00Z',
          actor: 'F-12345',
        },
        {
          from: 'SUBMITTED',
          to: 'AI_ANALYZED',
          timestamp: '2026-03-15T10:05:00Z',
          actor: 'AI_ENGINE',
        },
        {
          from: 'AI_ANALYZED',
          to: 'UNDER_REVIEW',
          timestamp: '2026-03-15T10:06:00Z',
          actor: 'POLICY_ENGINE',
        },
        {
          from: 'UNDER_REVIEW',
          to: 'APPROVED',
          timestamp: '2026-03-16T14:30:00Z',
          actor: 'insurance',
        },
      ],
      assignedAuthorities: ['insurance', 'state'],
      endorsements: [
        {
          authority: 'insurance',
          action: 'APPROVE',
          timestamp: '2026-03-16T14:30:00Z',
          reason: 'High risk score and strong evidence of crop loss',
        },
        {
          authority: 'state',
          action: 'APPROVE',
          timestamp: '2026-03-17T11:20:00Z',
          reason: 'Field verification confirms drought conditions',
        },
      ],
      aiEvidence: {
        riskScore: 0.78,
        confidence: 0.85,
        factors: [
          { factor: 'NDVI (Vegetation Index)', value: 0.35, impact: 'negative' },
          { factor: 'Rainfall Deviation', value: -45, impact: 'negative' },
          { factor: 'Soil Moisture', value: 22, impact: 'negative' },
        ],
        ndviData: [
          { month: 'Jan', value: 0.65 },
          { month: 'Feb', value: 0.68 },
          { month: 'Mar', value: 0.72 },
          { month: 'Apr', value: 0.45 },
          { month: 'May', value: 0.38 },
          { month: 'Jun', value: 0.35 },
        ],
        rainfallData: [
          { month: 'Jan', value: 12 },
          { month: 'Feb', value: 18 },
          { month: 'Mar', value: 25 },
          { month: 'Apr', value: 8 },
          { month: 'May', value: 5 },
          { month: 'Jun', value: 3 },
        ],
        soilData: [
          { month: 'Jan', value: 45 },
          { month: 'Feb', value: 48 },
          { month: 'Mar', value: 52 },
          { month: 'Apr', value: 32 },
          { month: 'May', value: 28 },
          { month: 'Jun', value: 22 },
        ],
      },
      payoutAmount: 45000,
      blockchainHash: '0x1a2b3c4d5e6f7g8h9i0j',
    },
  ]);

  const addStateTransition = (
    claim: Claim,
    to: ClaimState,
    actor: string,
    reason?: string
  ): StateTransition => {
    const transition: StateTransition = {
      from: claim.currentState,
      to,
      timestamp: new Date().toISOString(),
      actor,
      reason,
    };
    return transition;
  };

  const submitClaim = async (
    farmerId: string,
    farmerName: string,
    cropType: string,
    region: string,
    season: string,
    incidentType: string
  ): Promise<Claim> => {
    return new Promise((resolve) => {
      const claimId = `CLM-2026-${String(claims.length + 1).padStart(3, '0')}`;

      const newClaim: Claim = {
        id: claimId,
        farmerId,
        farmerName,
        cropType,
        region,
        season,
        incidentType,
        submittedDate: new Date().toISOString().split('T')[0],
        currentState: 'SUBMITTED',
        stateHistory: [
          {
            from: 'DRAFT',
            to: 'SUBMITTED',
            timestamp: new Date().toISOString(),
            actor: farmerId,
          },
        ],
        assignedAuthorities: [],
        endorsements: [],
      };

      setClaims((prev) => [...prev, newClaim]);
      resolve(newClaim);
    });
  };

  const processAIAnalysis = (claimId: string) => {
    setClaims((prev) =>
      prev.map((claim) => {
        if (claim.id !== claimId) return claim;

        const aiEvidence = generateAIEvidence(claim.cropType, claim.incidentType);
        const authorities = assignAuthorities(aiEvidence);

        const transition = addStateTransition(claim, 'AI_ANALYZED', 'AI_ENGINE');

        return {
          ...claim,
          currentState: 'AI_ANALYZED',
          aiEvidence,
          assignedAuthorities: authorities,
          stateHistory: [...claim.stateHistory, transition],
          blockchainHash: `0x${Math.random().toString(16).substring(2, 18)}`,
        };
      })
    );

    // Automatically move to UNDER_REVIEW
    setTimeout(() => {
      setClaims((prev) =>
        prev.map((claim) => {
          if (claim.id !== claimId || claim.currentState !== 'AI_ANALYZED') return claim;

          const transition = addStateTransition(claim, 'UNDER_REVIEW', 'POLICY_ENGINE');

          return {
            ...claim,
            currentState: 'UNDER_REVIEW',
            stateHistory: [...claim.stateHistory, transition],
          };
        })
      );
    }, 500);
  };

  const submitAuthorityAction = (
    claimId: string,
    authority: AuthorityType,
    action: AuthorityAction,
    reason: string
  ) => {
    setClaims((prev) =>
      prev.map((claim) => {
        if (claim.id !== claimId) return claim;

        const endorsement: AuthorityEndorsement = {
          authority,
          action,
          timestamp: new Date().toISOString(),
          reason,
        };

        const updatedEndorsements = [...claim.endorsements, endorsement];

        // Determine new state based on action
        let newState: ClaimState = claim.currentState;
        let actor = authority;

        if (action === 'ESCALATE') {
          newState = 'ESCALATED';
          // Add central authority if not already assigned
          if (!claim.assignedAuthorities.includes('central')) {
            claim.assignedAuthorities.push('central');
          }
        } else if (action === 'REJECT') {
          newState = 'REJECTED';
        } else if (action === 'APPROVE') {
          // Check if all mandatory authorities have approved
          const allApproved = claim.assignedAuthorities.every((auth) => {
            return updatedEndorsements.some(
              (e) => e.authority === auth && e.action === 'APPROVE'
            );
          });

          if (allApproved) {
            newState = 'APPROVED';
          } else {
            newState = 'ENDORSED';
          }
        }

        // Check for conflicts (one approves, another rejects)
        const hasApproval = updatedEndorsements.some((e) => e.action === 'APPROVE');
        const hasRejection = updatedEndorsements.some((e) => e.action === 'REJECT');

        if (hasApproval && hasRejection) {
          newState = 'ESCALATED';
          if (!claim.assignedAuthorities.includes('central')) {
            claim.assignedAuthorities.push('central');
          }
          reason = 'Conflict detected: escalated to central authority';
        }

        const transition = addStateTransition(claim, newState, actor, reason);

        const updatedClaim = {
          ...claim,
          currentState: newState,
          endorsements: updatedEndorsements,
          stateHistory: [...claim.stateHistory, transition],
        };

        // If approved, calculate payout and move to PAYOUT_PENDING
        if (newState === 'APPROVED') {
          setTimeout(() => {
            setClaims((current) =>
              current.map((c) => {
                if (c.id !== claimId) return c;

                const payoutTransition = addStateTransition(
                  c,
                  'PAYOUT_PENDING',
                  'SYSTEM'
                );

                return {
                  ...c,
                  currentState: 'PAYOUT_PENDING',
                  payoutAmount: Math.floor(20000 + Math.random() * 40000),
                  stateHistory: [...c.stateHistory, payoutTransition],
                };
              })
            );
          }, 1000);
        }

        return updatedClaim;
      })
    );
  };

  const disbursePayout = (claimId: string) => {
    setClaims((prev) =>
      prev.map((claim) => {
        if (claim.id !== claimId) return claim;

        const transition = addStateTransition(claim, 'PAID', 'bank');

        return {
          ...claim,
          currentState: 'PAID',
          payoutDate: new Date().toISOString().split('T')[0],
          stateHistory: [...claim.stateHistory, transition],
        };
      })
    );
  };

  const getClaimById = (claimId: string) => {
    return claims.find((c) => c.id === claimId);
  };

  const getClaimsForAuthority = (authority: AuthorityType): Claim[] => {
    return claims.filter((claim) => {
      // Only show claims assigned to this authority
      if (!claim.assignedAuthorities.includes(authority)) return false;

      // Don't show if already acted upon by this authority
      const hasActed = claim.endorsements.some((e) => e.authority === authority);
      if (hasActed && claim.currentState !== 'ESCALATED') return false;

      // Show if in appropriate state
      return ['UNDER_REVIEW', 'ENDORSED', 'ESCALATED'].includes(claim.currentState);
    });
  };

  const getClaimsForFarmer = (farmerId: string): Claim[] => {
    return claims.filter((c) => c.farmerId === farmerId);
  };

  return (
    <ClaimContext.Provider
      value={{
        claims,
        submitClaim,
        processAIAnalysis,
        submitAuthorityAction,
        disbursePayout,
        getClaimById,
        getClaimsForAuthority,
        getClaimsForFarmer,
      }}
    >
      {children}
    </ClaimContext.Provider>
  );
}

export function useClaims() {
  const context = useContext(ClaimContext);
  if (!context) {
    throw new Error('useClaims must be used within ClaimProvider');
  }
  return context;
}
