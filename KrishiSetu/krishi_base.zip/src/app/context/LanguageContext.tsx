import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  // Landing Page
  system_title: {
    en: 'Agricultural Claim Validation System',
    hi: 'कृषि दावा सत्यापन प्रणाली',
  },
  hero_title: {
    en: 'Transparent Crop Insurance Claim System',
    hi: 'पारदर्शी फसल बीमा दावा प्रणाली',
  },
  hero_subtitle: {
    en: 'AI-powered, blockchain-secured, and fully explainable claim processing',
    hi: 'एआई-संचालित, ब्लॉकचेन-सुरक्षित, और पूर्णतः व्याख्यात्मक दावा प्रसंस्करण',
  },
  farmer_login: {
    en: 'Farmer Login',
    hi: 'किसान लॉगिन',
  },
  authority_login: {
    en: 'Authority Login',
    hi: 'प्राधिकरण लॉगिन',
  },
  submit_claim: {
    en: 'Submit Claim',
    hi: 'दावा जमा करें',
  },
  track_claim: {
    en: 'Track Claim',
    hi: 'दावा ट्रैक करें',
  },
  policy_rules: {
    en: 'Policy Rules',
    hi: 'नीति नियम',
  },
  transparency_dashboard: {
    en: 'Transparency Dashboard',
    hi: 'पारदर्शिता डैशबोर्ड',
  },
  about: {
    en: 'About',
    hi: 'के बारे में',
  },
  how_it_works: {
    en: 'How It Works',
    hi: 'यह कैसे काम करता है',
  },
  policies: {
    en: 'Policies',
    hi: 'नीतियां',
  },
  claims: {
    en: 'Claims',
    hi: 'दावे',
  },
  login: {
    en: 'Login',
    hi: 'लॉगिन',
  },
  logout: {
    en: 'Logout',
    hi: 'लॉगआउट',
  },

  // Login
  enter_mobile: {
    en: 'Enter Mobile Number',
    hi: 'मोबाइल नंबर दर्ज करें',
  },
  send_otp: {
    en: 'Send OTP',
    hi: 'ओटीपी भेजें',
  },
  enter_otp: {
    en: 'Enter OTP',
    hi: 'ओटीपी दर्ज करें',
  },
  verify: {
    en: 'Verify',
    hi: 'सत्यापित करें',
  },
  select_role: {
    en: 'Select Your Role',
    hi: 'अपनी भूमिका चुनें',
  },

  // Dashboard
  welcome_farmer: {
    en: 'Welcome, Farmer',
    hi: 'स्वागत है, किसान',
  },
  submit_new_claim: {
    en: 'Submit New Claim',
    hi: 'नया दावा जमा करें',
  },
  track_existing_claim: {
    en: 'Track Existing Claim',
    hi: 'मौजूदा दावा ट्रैक करें',
  },
  total_claims: {
    en: 'Total Claims',
    hi: 'कुल दावे',
  },
  approved_claims: {
    en: 'Approved Claims',
    hi: 'स्वीकृत दावे',
  },

  // Claim Submission
  crop_type: {
    en: 'Crop Type',
    hi: 'फसल का प्रकार',
  },
  region: {
    en: 'Region',
    hi: 'क्षेत्र',
  },
  season: {
    en: 'Season',
    hi: 'मौसम',
  },
  incident_type: {
    en: 'Incident Type',
    hi: 'घटना का प्रकार',
  },
  analyzing_data: {
    en: 'Analyzing satellite and environmental data...',
    hi: 'उपग्रह और पर्यावरण डेटा का विश्लेषण किया जा रहा है...',
  },

  // Status
  submitted: {
    en: 'Submitted',
    hi: 'प्रस्तुत',
  },
  evidence_generated: {
    en: 'Evidence Generated',
    hi: 'साक्ष्य तैयार',
  },
  under_validation: {
    en: 'Under Validation',
    hi: 'सत्यापन के अधीन',
  },
  approved: {
    en: 'Approved',
    hi: 'स्वीकृत',
  },
  rejected: {
    en: 'Rejected',
    hi: 'अस्वीकृत',
  },
  pending: {
    en: 'Pending',
    hi: 'लंबित',
  },

  // Explainable AI
  decision_explanation: {
    en: 'Decision Explanation',
    hi: 'निर्णय की व्याख्या',
  },
  risk_score: {
    en: 'Risk Score',
    hi: 'जोखिम स्कोर',
  },
  confidence: {
    en: 'Confidence',
    hi: 'विश्वास',
  },
  key_factors: {
    en: 'Key Factors',
    hi: 'मुख्य कारक',
  },
  conclusion: {
    en: 'Conclusion',
    hi: 'निष्कर्ष',
  },
  low_ndvi: {
    en: 'Low NDVI detected',
    hi: 'कम एनडीवीआई का पता चला',
  },
  rainfall_deficit: {
    en: 'Rainfall deficiency',
    hi: 'वर्षा की कमी',
  },
  soil_moisture_low: {
    en: 'Soil moisture below threshold',
    hi: 'मृदा नमी सीमा से नीचे',
  },
  high_crop_loss: {
    en: 'High probability of crop loss',
    hi: 'फसल नुकसान की उच्च संभावना',
  },
  insufficient_evidence: {
    en: 'Insufficient evidence of crop loss',
    hi: 'फसल नुकसान के अपर्याप्त साक्ष्य',
  },

  // Roles
  farmer: {
    en: 'Farmer',
    hi: 'किसान',
  },
  insurance: {
    en: 'Insurance Authority',
    hi: 'बीमा प्राधिकरण',
  },
  state: {
    en: 'State Authority',
    hi: 'राज्य प्राधिकरण',
  },
  central: {
    en: 'Central Authority (MoA)',
    hi: 'केंद्रीय प्राधिकरण (कृषि मंत्रालय)',
  },
  audit: {
    en: 'Audit Authority',
    hi: 'लेखा परीक्षा प्राधिकरण',
  },
  bank: {
    en: 'Bank',
    hi: 'बैंक',
  },

  // Actions
  approve: {
    en: 'Approve',
    hi: 'स्वीकृत करें',
  },
  reject: {
    en: 'Reject',
    hi: 'अस्वीकार करें',
  },
  disburse: {
    en: 'Disburse Payment',
    hi: 'भुगतान वितरित करें',
  },
  back_to_home: {
    en: 'Back to Home',
    hi: 'मुख्य पृष्ठ पर वापस जाएं',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    const translation = translations[key as keyof typeof translations];
    if (!translation) return key;
    return translation[language];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
