import { AIEvidence, AuthorityType, PolicyRule } from '../types/claim';

// Policy Engine - Core system logic
export const POLICY_RULES: PolicyRule[] = [
  {
    condition: (evidence) => evidence.riskScore < 0.4 && evidence.confidence > 0.7,
    authorities: ['insurance'],
    description: 'Low risk, high confidence → Insurance only',
  },
  {
    condition: (evidence) =>
      evidence.riskScore >= 0.4 && evidence.riskScore <= 0.7 && evidence.confidence >= 0.6,
    authorities: ['insurance', 'state'],
    description: 'Moderate risk → Insurance + State',
  },
  {
    condition: (evidence) => evidence.riskScore > 0.7 || evidence.confidence < 0.6,
    authorities: ['insurance', 'state', 'central'],
    description: 'High risk or low confidence → All authorities',
  },
];

export function assignAuthorities(evidence: AIEvidence): AuthorityType[] {
  for (const rule of POLICY_RULES) {
    if (rule.condition(evidence)) {
      return rule.authorities;
    }
  }
  // Default fallback
  return ['insurance'];
}

export function getApplicableRule(evidence: AIEvidence): PolicyRule | undefined {
  return POLICY_RULES.find((rule) => rule.condition(evidence));
}

// Generate mock AI evidence
export function generateAIEvidence(
  cropType: string,
  incidentType: string
): AIEvidence {
  // Simulate different risk levels based on incident type
  let riskScore: number;
  let confidence: number;

  switch (incidentType) {
    case 'Drought':
      riskScore = 0.75 + Math.random() * 0.2;
      confidence = 0.82 + Math.random() * 0.15;
      break;
    case 'Flood':
      riskScore = 0.68 + Math.random() * 0.25;
      confidence = 0.75 + Math.random() * 0.2;
      break;
    case 'Pest':
      riskScore = 0.45 + Math.random() * 0.3;
      confidence = 0.65 + Math.random() * 0.25;
      break;
    case 'Disease':
      riskScore = 0.5 + Math.random() * 0.35;
      confidence = 0.6 + Math.random() * 0.3;
      break;
    default:
      riskScore = Math.random();
      confidence = Math.random();
  }

  const factors = [
    {
      factor: 'NDVI (Vegetation Index)',
      value: riskScore > 0.6 ? 0.35 : 0.65,
      impact: riskScore > 0.6 ? ('negative' as const) : ('positive' as const),
    },
    {
      factor: 'Rainfall Deviation',
      value: riskScore > 0.6 ? -45 : -10,
      impact: riskScore > 0.6 ? ('negative' as const) : ('positive' as const),
    },
    {
      factor: 'Soil Moisture',
      value: riskScore > 0.6 ? 22 : 45,
      impact: riskScore > 0.6 ? ('negative' as const) : ('positive' as const),
    },
  ];

  const ndviData = [
    { month: 'Jan', value: 0.65 },
    { month: 'Feb', value: 0.68 },
    { month: 'Mar', value: 0.72 },
    { month: 'Apr', value: riskScore > 0.6 ? 0.45 : 0.68 },
    { month: 'May', value: riskScore > 0.6 ? 0.38 : 0.65 },
    { month: 'Jun', value: riskScore > 0.6 ? 0.35 : 0.62 },
  ];

  const rainfallData = [
    { month: 'Jan', value: 12 },
    { month: 'Feb', value: 18 },
    { month: 'Mar', value: 25 },
    { month: 'Apr', value: riskScore > 0.6 ? 8 : 22 },
    { month: 'May', value: riskScore > 0.6 ? 5 : 18 },
    { month: 'Jun', value: riskScore > 0.6 ? 3 : 15 },
  ];

  const soilData = [
    { month: 'Jan', value: 45 },
    { month: 'Feb', value: 48 },
    { month: 'Mar', value: 52 },
    { month: 'Apr', value: riskScore > 0.6 ? 32 : 48 },
    { month: 'May', value: riskScore > 0.6 ? 28 : 45 },
    { month: 'Jun', value: riskScore > 0.6 ? 22 : 42 },
  ];

  return {
    riskScore: Math.min(riskScore, 1),
    confidence: Math.min(confidence, 1),
    factors,
    ndviData,
    rainfallData,
    soilData,
  };
}
