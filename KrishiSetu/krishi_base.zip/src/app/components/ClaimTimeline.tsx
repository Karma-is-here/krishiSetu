import { CheckCircle, Clock, XCircle, AlertTriangle, Zap } from 'lucide-react';
import { Claim } from '../types/claim';
import { useLanguage } from '../context/LanguageContext';

interface ClaimTimelineProps {
  claim: Claim;
}

export default function ClaimTimeline({ claim }: ClaimTimelineProps) {
  const { t } = useLanguage();

  const timelineSteps = [
    { state: 'SUBMITTED', label: t('submitted'), icon: CheckCircle, color: 'green' },
    { state: 'AI_ANALYZED', label: t('evidence_generated'), icon: Zap, color: 'blue' },
    { state: 'UNDER_REVIEW', label: t('under_validation'), icon: Clock, color: 'amber' },
    { state: 'APPROVED', label: t('approved'), icon: CheckCircle, color: 'green' },
    { state: 'PAYOUT_PENDING', label: 'Payout Pending', icon: Clock, color: 'amber' },
    { state: 'PAID', label: 'Paid', icon: CheckCircle, color: 'green' },
  ];

  const isStepCompleted = (stepState: string) => {
    return claim.stateHistory.some((h) => h.to === stepState);
  };

  const isCurrentStep = (stepState: string) => {
    return claim.currentState === stepState;
  };

  const getStepTimestamp = (stepState: string) => {
    const history = claim.stateHistory.find((h) => h.to === stepState);
    return history ? new Date(history.timestamp).toLocaleString() : '';
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-lg mb-6">Claim Status & Timeline</h3>

      {/* Current State Summary */}
      <div className="mb-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-600">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Current Status</p>
            <p className="text-xl">{claim.currentState.replace('_', ' ')}</p>
          </div>
          <div className="text-right">
            {claim.assignedAuthorities.length > 0 && (
              <>
                <p className="text-sm text-gray-600">Assigned Authorities</p>
                <p className="text-sm capitalize">{claim.assignedAuthorities.join(', ')}</p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="space-y-4">
        {timelineSteps.map((step, idx) => {
          const completed = isStepCompleted(step.state);
          const current = isCurrentStep(step.state);
          const Icon = step.icon;

          // Special handling for rejected/escalated states
          if (claim.currentState === 'REJECTED' && step.state === 'APPROVED') {
            return null;
          }

          return (
            <div key={idx} className="flex items-start gap-4">
              <div
                className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                  completed || current
                    ? `bg-${step.color}-100`
                    : 'bg-gray-100'
                }`}
              >
                <Icon
                  className={`w-6 h-6 ${
                    completed || current
                      ? `text-${step.color}-600`
                      : 'text-gray-400'
                  }`}
                />
              </div>
              <div className="flex-1">
                <p className={completed || current ? '' : 'text-gray-400'}>{step.label}</p>
                {completed && (
                  <p className="text-sm text-gray-600">{getStepTimestamp(step.state)}</p>
                )}
                {current && !completed && (
                  <p className="text-sm text-amber-600">In Progress...</p>
                )}
              </div>
            </div>
          );
        })}

        {/* Special states */}
        {claim.currentState === 'REJECTED' && (
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-red-100">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
            <div className="flex-1">
              <p>{t('rejected')}</p>
              <p className="text-sm text-gray-600">{getStepTimestamp('REJECTED')}</p>
            </div>
          </div>
        )}

        {claim.currentState === 'ESCALATED' && (
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-orange-100">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
            </div>
            <div className="flex-1">
              <p>Escalated</p>
              <p className="text-sm text-gray-600">{getStepTimestamp('ESCALATED')}</p>
              <p className="text-sm text-orange-700 mt-1">
                Escalated to Central Authority for review
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Authority Endorsements */}
      {claim.endorsements.length > 0 && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h4 className="text-sm mb-3">Authority Decisions</h4>
          <div className="space-y-2">
            {claim.endorsements.map((endorsement, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm capitalize">{endorsement.authority}</p>
                    <span
                      className={`text-xs px-2 py-0.5 rounded ${
                        endorsement.action === 'APPROVE'
                          ? 'bg-green-100 text-green-700'
                          : endorsement.action === 'REJECT'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-orange-100 text-orange-700'
                      }`}
                    >
                      {endorsement.action}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-1">{endorsement.reason}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(endorsement.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Blockchain Hash */}
      {claim.blockchainHash && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-600 mb-1">Blockchain Hash</p>
          <p className="text-xs font-mono bg-gray-100 p-2 rounded break-all">
            {claim.blockchainHash}
          </p>
        </div>
      )}
    </div>
  );
}
