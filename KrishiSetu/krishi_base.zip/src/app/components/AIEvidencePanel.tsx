import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingDown, TrendingUp } from 'lucide-react';
import { Claim, AIEvidence } from '../types/claim';
import { useLanguage } from '../context/LanguageContext';
import { getApplicableRule } from '../utils/policyEngine';

interface AIEvidencePanelProps {
  claim: Claim;
  evidence: AIEvidence;
}

export default function AIEvidencePanel({ claim, evidence }: AIEvidencePanelProps) {
  const { t } = useLanguage();
  const applicableRule = getApplicableRule(evidence);

  const getRiskLevel = (score: number) => {
    if (score < 0.4) return { label: 'Low', color: 'green' };
    if (score < 0.7) return { label: 'Moderate', color: 'amber' };
    return { label: 'High', color: 'red' };
  };

  const riskLevel = getRiskLevel(evidence.riskScore);

  return (
    <div className="space-y-6">
      {/* AI Analysis Summary */}
      <div className="bg-white p-6 rounded-lg shadow-md border-2 border-blue-200">
        <h3 className="text-lg mb-4 flex items-center gap-2">
          <span className="text-blue-600">🤖</span>
          AI Evidence Analysis
        </h3>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className={`bg-${riskLevel.color}-50 p-4 rounded-lg border-2 border-${riskLevel.color}-200`}>
            <p className="text-sm text-gray-600 mb-1">{t('risk_score')}</p>
            <p className="text-2xl">{evidence.riskScore.toFixed(2)}</p>
            <p className={`text-sm text-${riskLevel.color}-700 mt-1`}>
              {riskLevel.label} Risk
            </p>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <p className="text-sm text-gray-600 mb-1">{t('confidence')}</p>
            <p className="text-2xl">{evidence.confidence.toFixed(2)}</p>
            <p className="text-sm text-blue-700 mt-1">
              {evidence.confidence > 0.8 ? 'High' : evidence.confidence > 0.6 ? 'Medium' : 'Low'} Confidence
            </p>
          </div>
        </div>

        {/* Policy Rule Applied */}
        {applicableRule && (
          <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-600 mb-6">
            <p className="text-sm mb-1">
              <strong>Policy Rule Applied:</strong>
            </p>
            <p className="text-sm text-gray-700">{applicableRule.description}</p>
            <p className="text-sm text-purple-700 mt-2">
              Assigned Authorities: {claim.assignedAuthorities.map(a => a.toUpperCase()).join(' → ')}
            </p>
          </div>
        )}

        {/* Key Factors */}
        <div className="mb-6">
          <p className="text-sm mb-3">{t('key_factors')}:</p>
          <div className="space-y-2">
            {evidence.factors.map((factor, idx) => (
              <div key={idx} className="flex items-start gap-2">
                {factor.impact === 'negative' ? (
                  <TrendingDown className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                ) : (
                  <TrendingUp className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                )}
                <div className="flex-1">
                  <p className="text-sm">{factor.factor}</p>
                  <p className="text-xs text-gray-600">Value: {factor.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Decision Summary */}
        <div
          className={`p-4 rounded-lg ${
            claim.currentState === 'APPROVED' || claim.currentState === 'PAID'
              ? 'bg-green-50 border-2 border-green-200'
              : claim.currentState === 'REJECTED'
              ? 'bg-red-50 border-2 border-red-200'
              : 'bg-amber-50 border-2 border-amber-200'
          }`}
        >
          <p className="text-sm mb-1">
            <strong>{t('conclusion')}:</strong>
          </p>
          <p
            className={
              claim.currentState === 'APPROVED' || claim.currentState === 'PAID'
                ? 'text-green-800'
                : claim.currentState === 'REJECTED'
                ? 'text-red-800'
                : 'text-amber-800'
            }
          >
            {claim.currentState === 'APPROVED' || claim.currentState === 'PAID'
              ? 'High probability of crop loss detected. Claim eligible for approval.'
              : claim.currentState === 'REJECTED'
              ? 'Insufficient evidence of crop loss. Claim not eligible.'
              : 'Evidence under review by assigned authorities.'}
          </p>
        </div>
      </div>

      {/* Environmental Data Charts */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg mb-4">Environmental Data Analysis</h3>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div>
            <h4 className="text-sm mb-3">NDVI Index</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={evidence.ndviData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" style={{ fontSize: '12px' }} />
                <YAxis style={{ fontSize: '12px' }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div>
            <h4 className="text-sm mb-3">Rainfall (mm)</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={evidence.rainfallData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" style={{ fontSize: '12px' }} />
                <YAxis style={{ fontSize: '12px' }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div>
            <h4 className="text-sm mb-3">Soil Moisture (%)</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={evidence.soilData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" style={{ fontSize: '12px' }} />
                <YAxis style={{ fontSize: '12px' }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#f59e0b" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
