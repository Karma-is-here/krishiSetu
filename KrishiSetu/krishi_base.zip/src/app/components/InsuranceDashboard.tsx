import { useState } from 'react';
import { LogOut, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import { useClaims } from '../context/ClaimContext';
import { AuthorityAction } from '../types/claim';
import AIEvidencePanel from './AIEvidencePanel';

interface DashboardProps {
  onLogout: () => void;
}

export default function InsuranceDashboard({ onLogout }: DashboardProps) {
  const { getClaimsForAuthority, submitAuthorityAction } = useClaims();
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [showActionDialog, setShowActionDialog] = useState<AuthorityAction | null>(null);

  const claims = getClaimsForAuthority('insurance');
  const selectedClaim = selectedClaimId
    ? claims.find((c) => c.id === selectedClaimId)
    : null;

  const handleAction = (action: AuthorityAction) => {
    if (!selectedClaim) return;

    let defaultReason = '';
    switch (action) {
      case 'APPROVE':
        defaultReason = `High risk score (${selectedClaim.aiEvidence?.riskScore.toFixed(2)}), strong evidence of crop loss`;
        break;
      case 'REJECT':
        defaultReason = `Insufficient evidence, low risk score (${selectedClaim.aiEvidence?.riskScore.toFixed(2)})`;
        break;
      case 'ESCALATE':
        defaultReason = 'Requires additional validation from higher authority';
        break;
    }

    setActionReason(defaultReason);
    setShowActionDialog(action);
  };

  const confirmAction = () => {
    if (!selectedClaim || !showActionDialog) return;

    submitAuthorityAction(selectedClaim.id, 'insurance', showActionDialog, actionReason);
    setShowActionDialog(null);
    setActionReason('');
    setSelectedClaimId(null);
  };

  const pendingClaims = claims.filter(
    (c) => !c.endorsements.some((e) => e.authority === 'insurance')
  );

  return (
    <div className="size-full flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-blue-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl">Insurance Authority Dashboard</h1>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-blue-800 px-4 py-2 rounded-lg hover:bg-blue-900 transition"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Info Banner */}
          <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-8 rounded">
            <p className="text-sm">
              <strong>Your Role:</strong> Primary validator - Review AI evidence and approve, reject, or escalate claims
            </p>
            <p className="text-sm mt-2">
              <strong>Visibility:</strong> You see only claims assigned to you by the policy engine
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Assigned Claims</h3>
              <p className="text-3xl text-blue-600">{claims.length}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Pending Review</h3>
              <p className="text-3xl text-amber-600">{pendingClaims.length}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Actions Taken</h3>
              <p className="text-3xl text-green-600">{claims.length - pendingClaims.length}</p>
            </div>
          </div>

          {/* Claims Review Panel */}
          <h2 className="text-2xl mb-6">Claim Review Queue</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              {claims.length === 0 ? (
                <div className="bg-white p-6 rounded-lg shadow-md text-center text-gray-500">
                  <p>No claims assigned to you at the moment</p>
                </div>
              ) : (
                claims.map((claim) => {
                  const hasActed = claim.endorsements.some((e) => e.authority === 'insurance');

                  return (
                    <button
                      key={claim.id}
                      onClick={() => setSelectedClaimId(claim.id)}
                      className={`w-full text-left bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition border-2 ${
                        selectedClaimId === claim.id ? 'border-blue-500' : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">{claim.id}</span>
                        {hasActed && <CheckCircle className="w-5 h-5 text-green-600" />}
                      </div>
                      <p className="mb-1">{claim.cropType}</p>
                      <p className="text-sm text-gray-600 mb-2">{claim.incidentType}</p>
                      {claim.aiEvidence && (
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-red-50 p-2 rounded">
                            <p className="text-xs text-gray-600">Risk</p>
                            <p className="text-sm">{claim.aiEvidence.riskScore.toFixed(2)}</p>
                          </div>
                          <div className="bg-blue-50 p-2 rounded">
                            <p className="text-xs text-gray-600">Confidence</p>
                            <p className="text-sm">{claim.aiEvidence.confidence.toFixed(2)}</p>
                          </div>
                        </div>
                      )}
                    </button>
                  );
                })
              )}
            </div>

            <div className="lg:col-span-2">
              {selectedClaim ? (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-lg mb-4">Claim Details</h3>
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div>
                        <p className="text-sm text-gray-600">Claim ID</p>
                        <p>{selectedClaim.id}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Farmer</p>
                        <p>{selectedClaim.farmerName}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Crop Type</p>
                        <p>{selectedClaim.cropType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Region</p>
                        <p>{selectedClaim.region}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Incident Type</p>
                        <p>{selectedClaim.incidentType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Status</p>
                        <p className="capitalize">{selectedClaim.currentState.replace('_', ' ')}</p>
                      </div>
                    </div>

                    {!selectedClaim.endorsements.some((e) => e.authority === 'insurance') && (
                      <div className="flex gap-3">
                        <button
                          onClick={() => handleAction('APPROVE')}
                          className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition flex items-center justify-center gap-2"
                        >
                          <CheckCircle className="w-5 h-5" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleAction('ESCALATE')}
                          className="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition flex items-center justify-center gap-2"
                        >
                          <AlertTriangle className="w-5 h-5" />
                          Escalate
                        </button>
                        <button
                          onClick={() => handleAction('REJECT')}
                          className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition flex items-center justify-center gap-2"
                        >
                          <XCircle className="w-5 h-5" />
                          Reject
                        </button>
                      </div>
                    )}

                    {selectedClaim.endorsements.some((e) => e.authority === 'insurance') && (
                      <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
                        <p className="text-sm text-green-800">
                          ✓ You have already acted on this claim
                        </p>
                      </div>
                    )}
                  </div>

                  {selectedClaim.aiEvidence && (
                    <AIEvidencePanel claim={selectedClaim} evidence={selectedClaim.aiEvidence} />
                  )}
                </div>
              ) : (
                <div className="bg-white p-12 rounded-lg shadow-md text-center text-gray-500">
                  <p>Select a claim to review details and evidence</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Action Confirmation Dialog */}
      {showActionDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-xl mb-4">
              Confirm {showActionDialog} Action
            </h3>
            <div className="mb-4">
              <label className="block mb-2 text-sm">Reason for decision:</label>
              <textarea
                value={actionReason}
                onChange={(e) => setActionReason(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg"
                rows={3}
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={confirmAction}
                className={`flex-1 text-white py-2 rounded-lg transition ${
                  showActionDialog === 'APPROVE'
                    ? 'bg-green-600 hover:bg-green-700'
                    : showActionDialog === 'REJECT'
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-amber-600 hover:bg-amber-700'
                }`}
              >
                Confirm {showActionDialog}
              </button>
              <button
                onClick={() => setShowActionDialog(null)}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
