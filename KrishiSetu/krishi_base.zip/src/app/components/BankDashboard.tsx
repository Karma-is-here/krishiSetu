import { LogOut, Wallet, CheckCircle } from 'lucide-react';
import { useClaims } from '../context/ClaimContext';

interface DashboardProps {
  onLogout: () => void;
}

export default function BankDashboard({ onLogout }: DashboardProps) {
  const { claims, disbursePayout } = useClaims();

  const payoutClaims = claims.filter((c) =>
    ['PAYOUT_PENDING', 'PAID'].includes(c.currentState)
  );

  const handleDisburse = (claimId: string) => {
    disbursePayout(claimId);
  };

  const pendingPayouts = payoutClaims.filter((c) => c.currentState === 'PAYOUT_PENDING');
  const disbursed = payoutClaims.filter((c) => c.currentState === 'PAID');

  const totalPending = pendingPayouts.reduce((sum, c) => sum + (c.payoutAmount || 0), 0);
  const totalDisbursed = disbursed.reduce((sum, c) => sum + (c.payoutAmount || 0), 0);

  return (
    <div className="size-full flex flex-col bg-gray-50">
      <header className="bg-emerald-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl">Bank Dashboard</h1>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-emerald-800 px-4 py-2 rounded-lg hover:bg-emerald-900 transition"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="bg-emerald-50 border-l-4 border-emerald-600 p-4 mb-8 rounded">
            <p className="text-sm">
              <strong>Role:</strong> Payout execution for approved claims
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Pending Payouts</h3>
              <p className="text-3xl text-amber-600">{pendingPayouts.length}</p>
              <p className="text-sm text-gray-600 mt-2">₹ {totalPending.toLocaleString('en-IN')}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Disbursed</h3>
              <p className="text-3xl text-green-600">{disbursed.length}</p>
              <p className="text-sm text-gray-600 mt-2">₹ {totalDisbursed.toLocaleString('en-IN')}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Total Claims</h3>
              <p className="text-3xl text-emerald-600">{payoutClaims.length}</p>
            </div>
          </div>

          <h2 className="text-2xl mb-6">Approved Claims - Payout Queue</h2>
          <div className="space-y-4">
            {payoutClaims.map((claim) => (
              <div
                key={claim.id}
                className={`bg-white p-6 rounded-lg shadow-md border-2 ${
                  claim.currentState === 'PAID'
                    ? 'border-green-200 bg-green-50'
                    : 'border-gray-200'
                }`}
              >
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                  <div>
                    <p className="text-sm text-gray-600">Claim ID</p>
                    <p>{claim.id}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Farmer</p>
                    <p>{claim.farmerName}</p>
                    <p className="text-xs text-gray-500">{claim.farmerId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Crop Type</p>
                    <p>{claim.cropType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Amount</p>
                    <p className="text-lg text-emerald-700">
                      ₹ {(claim.payoutAmount || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div>
                    {claim.currentState === 'PAID' ? (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-5 h-5" />
                        <div>
                          <p className="text-sm">Disbursed</p>
                          <p className="text-xs text-gray-500">{claim.payoutDate}</p>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleDisburse(claim.id)}
                        className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition flex items-center justify-center gap-2"
                      >
                        <Wallet className="w-4 h-4" />
                        Disburse
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
