import { useState } from 'react';
import { UserRole } from '../App';
import { Building2, MapPin, Landmark, Shield, Wallet } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface AuthorityLoginProps {
  onLoginComplete: (role: Exclude<UserRole, 'farmer' | null>) => void;
}

export default function AuthorityLogin({ onLoginComplete }: AuthorityLoginProps) {
  const { t } = useLanguage();
  const [selectedRole, setSelectedRole] = useState<Exclude<UserRole, 'farmer' | null> | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const roles = [
    { id: 'insurance' as const, name: t('insurance'), icon: Building2, color: 'blue' },
    { id: 'state' as const, name: t('state'), icon: MapPin, color: 'purple' },
    { id: 'central' as const, name: t('central'), icon: Landmark, color: 'red' },
    { id: 'audit' as const, name: t('audit'), icon: Shield, color: 'amber' },
    { id: 'bank' as const, name: t('bank'), icon: Wallet, color: 'emerald' },
  ];

  const handleLogin = () => {
    if (selectedRole && username && password) {
      onLoginComplete(selectedRole);
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-4xl w-full mx-auto px-6">
        {!selectedRole ? (
          <>
            <h1 className="text-3xl text-center mb-12">{t('select_role')}</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {roles.map((role) => {
                const Icon = role.icon;
                return (
                  <button
                    key={role.id}
                    onClick={() => setSelectedRole(role.id)}
                    className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition transform hover:-translate-y-1 border-2 border-gray-200 hover:border-blue-400"
                  >
                    <Icon className={`w-16 h-16 text-${role.color}-600 mx-auto mb-4`} />
                    <h3 className="text-lg text-center">{role.name}</h3>
                  </button>
                );
              })}
            </div>
          </>
        ) : (
          <div className="max-w-md mx-auto">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <h1 className="text-2xl text-center mb-6">
                {roles.find((r) => r.id === selectedRole)?.name}
              </h1>
              <div className="space-y-4">
                <div>
                  <label className="block mb-2 text-sm">Username</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-600 focus:outline-none"
                    placeholder="Enter username"
                  />
                </div>
                <div>
                  <label className="block mb-2 text-sm">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-600 focus:outline-none"
                    placeholder="Enter password"
                  />
                </div>
                <p className="text-xs text-gray-500">For demo, enter any credentials</p>
                <button
                  onClick={handleLogin}
                  disabled={!username || !password}
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {t('login')}
                </button>
                <button
                  onClick={() => setSelectedRole(null)}
                  className="w-full text-blue-600 hover:underline"
                >
                  {t('back_to_home')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
