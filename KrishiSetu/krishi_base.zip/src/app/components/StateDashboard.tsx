import { useState } from 'react';
import { LogOut, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useClaims } from '../context/ClaimContext';
import { AuthorityAction } from '../types/claim';
import AIEvidencePanel from './AIEvidencePanel';

interface DashboardProps {
  onLogout: () => void;
}

export default function StateDashboard({ onLogout }: DashboardProps) {
  const { getClaimsForAuthority, submitAuthorityAction } = useClaims();
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [showActionDialog, setShowActionDialog] = useState<AuthorityAction | null>(null);

  const claims = getClaimsForAuthority('state');
  const selectedClaim = selectedClaimId ? claims.find((c) => c.id === selectedClaimId) : null;

  const handleAction = (action: AuthorityAction) => {
    if (!selectedClaim) return;

    let defaultReason = '';
    switch (action) {
      case 'APPROVE':
        defaultReason = 'Field verification confirms crop loss and validates insurance assessment';
        break;
      case 'REJECT':
        defaultReason = 'Field verification does not support claim';
        break;
      case 'ESCALATE':
        defaultReason = 'Complex case requiring central authority review';
        break;
    }

    setActionReason(defaultReason);
    setShowActionDialog(action);
  };

  const confirmAction = () => {
    if (!selectedClaim || !showActionDialog) return;

    submitAuthorityAction(selectedClaim.id, 'state', showActionDialog, actionReason);
    setShowActionDialog(null);
    setActionReason('');
    setSelectedClaimId(null);
  };

  return (
    <div className="size-full flex flex-col bg-gray-50">
      <header className="bg-purple-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl">State Authority Dashboard</h1>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-purple-800 px-4 py-2 rounded-lg hover:bg-purple-900 transition"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="bg-purple-50 border-l-4 border-purple-600 p-4 mb-8 rounded">
            <p className="text-sm">
              <strong>Role:</strong> Secondary validator - Field-level verification and validation
            </p>
            <p className="text-sm mt-2">
              <strong>Visibility:</strong> Only moderate and high-risk claims assigned by policy engine
            </p>
          </div>

          <h2 className="text-2xl mb-6">Claims Requiring State Validation</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              {claims.length === 0 ? (
                <div className="bg-white p-6 rounded-lg shadow-md text-center text-gray-500">
                  <p>No claims assigned</p>
                </div>
              ) : (
                claims.map((claim) => {
                  const hasActed = claim.endorsements.some((e) => e.authority === 'state');
                  return (
                    <button
                      key={claim.id}
                      onClick={() => setSelectedClaimId(claim.id)}
                      className={`w-full text-left bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition border-2 ${
                        selectedClaimId === claim.id ? 'border-purple-500' : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">{claim.id}</span>
                        {hasActed && <CheckCircle className="w-5 h-5 text-green-600" />}
                      </div>
                      <p className="mb-1">{claim.cropType}</p>
                      <p className="text-sm text-gray-600">{claim.incidentType}</p>
                    </button>
                  );
                })
              )}
            </div>

            <div className="lg:col-span-2">
              {selectedClaim ? (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-lg mb-4">Claim Details</h3>
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div>
                        <p className="text-sm text-gray-600">Claim ID</p>
                        <p>{selectedClaim.id}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Farmer</p>
                        <p>{selectedClaim.farmerName}</p>
                      </div>
                    </div>

                    {!selectedClaim.endorsements.some((e) => e.authority === 'state') && (
                      <div className="flex gap-3">
                        <button
                          onClick={() => handleAction('APPROVE')}
                          className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition flex items-center justify-center gap-2"
                        >
                          <CheckCircle className="w-5 h-5" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleAction('ESCALATE')}
                          className="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition flex items-center justify-center gap-2"
                        >
                          <AlertTriangle className="w-5 h-5" />
                          Escalate
                        </button>
                        <button
                          onClick={() => handleAction('REJECT')}
                          className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition flex items-center justify-center gap-2"
                        >
                          <XCircle className="w-5 h-5" />
                          Reject
                        </button>
                      </div>
                    )}
                  </div>

                  {selectedClaim.aiEvidence && (
                    <AIEvidencePanel claim={selectedClaim} evidence={selectedClaim.aiEvidence} />
                  )}
                </div>
              ) : (
                <div className="bg-white p-12 rounded-lg shadow-md text-center text-gray-500">
                  <p>Select a claim to review</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showActionDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-xl mb-4">Confirm {showActionDialog} Action</h3>
            <div className="mb-4">
              <label className="block mb-2 text-sm">Reason:</label>
              <textarea
                value={actionReason}
                onChange={(e) => setActionReason(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg"
                rows={3}
              />
            </div>
            <div className="flex gap-3">
              <button onClick={confirmAction} className="flex-1 bg-purple-600 text-white py-2 rounded-lg">
                Confirm
              </button>
              <button
                onClick={() => setShowActionDialog(null)}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
