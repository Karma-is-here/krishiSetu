import { useState } from 'react';
import { LogOut, Plus, Search, CheckCircle, Clock, XCircle, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useClaims } from '../context/ClaimContext';
import LoadingAnimation from './LoadingAnimation';
import ClaimTimeline from './ClaimTimeline';
import AIEvidencePanel from './AIEvidencePanel';

interface DashboardProps {
  onLogout: () => void;
}

const FARMER_ID = 'F-12345';
const FARMER_NAME = 'Ramesh Kumar';

export default function FarmerDashboard({ onLogout }: DashboardProps) {
  const { t } = useLanguage();
  const { submitClaim, processAIAnalysis, getClaimsForFarmer } = useClaims();
  const [currentView, setCurrentView] = useState<'home' | 'submit' | 'track'>('home');
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const claims = getClaimsForFarmer(FARMER_ID);

  const [formData, setFormData] = useState({
    cropType: '',
    incidentType: '',
  });

  const handleSubmitClaim = async () => {
    setIsLoading(true);

    // Step 1: Submit claim
    const claim = await submitClaim(
      FARMER_ID,
      FARMER_NAME,
      formData.cropType,
      'Maharashtra',
      'Kharif 2026',
      formData.incidentType
    );

    // Step 2: Simulate AI analysis after 3 seconds
    setTimeout(() => {
      processAIAnalysis(claim.id);
      setIsLoading(false);
      setFormData({ cropType: '', incidentType: '' });
      setCurrentView('track');
      setSelectedClaimId(claim.id);
    }, 3000);
  };

  const getStatusColor = (state: string) => {
    switch (state) {
      case 'APPROVED':
      case 'PAID':
        return 'text-green-600 bg-green-50';
      case 'REJECTED':
        return 'text-red-600 bg-red-50';
      case 'ESCALATED':
        return 'text-orange-600 bg-orange-50';
      case 'UNDER_REVIEW':
      case 'ENDORSED':
      case 'PAYOUT_PENDING':
        return 'text-amber-600 bg-amber-50';
      default:
        return 'text-blue-600 bg-blue-50';
    }
  };

  const getStatusIcon = (state: string) => {
    switch (state) {
      case 'APPROVED':
      case 'PAID':
        return <CheckCircle className="w-5 h-5" />;
      case 'REJECTED':
        return <XCircle className="w-5 h-5" />;
      case 'ESCALATED':
        return <AlertTriangle className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  const selectedClaim = selectedClaimId
    ? claims.find((c) => c.id === selectedClaimId)
    : null;

  return (
    <div className="size-full flex flex-col bg-gray-50">
      {isLoading && <LoadingAnimation />}

      {/* Header */}
      <header className="bg-green-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl">{t('farmer')} Dashboard</h1>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-green-800 px-4 py-2 rounded-lg hover:bg-green-900 transition"
          >
            <LogOut className="w-4 h-4" />
            {t('logout')}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Home View */}
          {currentView === 'home' && (
            <>
              <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-8 rounded-xl mb-8">
                <h2 className="text-2xl mb-2">{t('welcome_farmer')}</h2>
                <p className="opacity-90">Manage your agricultural insurance claims with transparency</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-lg mb-2">{t('total_claims')}</h3>
                  <p className="text-3xl text-green-600">{claims.length}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-lg mb-2">{t('approved_claims')}</h3>
                  <p className="text-3xl text-green-600">
                    {claims.filter((c) => c.currentState === 'APPROVED' || c.currentState === 'PAID').length}
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-lg mb-2">Active Claims</h3>
                  <p className="text-3xl text-amber-600">
                    {claims.filter((c) => !['APPROVED', 'PAID', 'REJECTED'].includes(c.currentState)).length}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <button
                  onClick={() => setCurrentView('submit')}
                  className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition border-2 border-green-200 hover:border-green-400"
                >
                  <Plus className="w-12 h-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg">{t('submit_new_claim')}</h3>
                </button>
                <button
                  onClick={() => setCurrentView('track')}
                  className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition border-2 border-blue-200 hover:border-blue-400"
                >
                  <Search className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-lg">{t('track_existing_claim')}</h3>
                </button>
              </div>
            </>
          )}

          {/* Submit Claim View */}
          {currentView === 'submit' && (
            <div className="max-w-2xl mx-auto">
              <button
                onClick={() => setCurrentView('home')}
                className="mb-6 text-green-700 hover:underline"
              >
                ← {t('back_to_home')}
              </button>
              <div className="bg-white p-8 rounded-xl shadow-md">
                <h2 className="text-2xl mb-6">{t('submit_new_claim')}</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block mb-2 text-sm">{t('crop_type')}</label>
                    <select
                      value={formData.cropType}
                      onChange={(e) => setFormData({ ...formData, cropType: e.target.value })}
                      className="w-full p-3 border border-gray-300 rounded-lg"
                    >
                      <option value="">Select crop type</option>
                      <option value="Rice">Rice / धान</option>
                      <option value="Wheat">Wheat / गेहूं</option>
                      <option value="Cotton">Cotton / कपास</option>
                      <option value="Sugarcane">Sugarcane / गन्ना</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">{t('region')}</label>
                    <input
                      type="text"
                      value="Maharashtra"
                      disabled
                      className="w-full p-3 border border-gray-300 rounded-lg bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">{t('season')}</label>
                    <input
                      type="text"
                      value="Kharif 2026"
                      disabled
                      className="w-full p-3 border border-gray-300 rounded-lg bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">{t('incident_type')}</label>
                    <select
                      value={formData.incidentType}
                      onChange={(e) => setFormData({ ...formData, incidentType: e.target.value })}
                      className="w-full p-3 border border-gray-300 rounded-lg"
                    >
                      <option value="">Select incident type</option>
                      <option value="Drought">Drought / सूखा</option>
                      <option value="Flood">Flood / बाढ़</option>
                      <option value="Pest">Pest Attack / कीट हमला</option>
                      <option value="Disease">Disease / रोग</option>
                    </select>
                  </div>
                  <button
                    onClick={handleSubmitClaim}
                    disabled={!formData.cropType || !formData.incidentType}
                    className="w-full bg-green-700 text-white py-3 rounded-lg hover:bg-green-800 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {t('submit_claim')}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Track Claim View */}
          {currentView === 'track' && (
            <>
              <button
                onClick={() => setCurrentView('home')}
                className="mb-6 text-green-700 hover:underline"
              >
                ← {t('back_to_home')}
              </button>
              <h2 className="text-2xl mb-6">{t('track_claim')}</h2>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="space-y-4">
                  {claims.map((claim) => (
                    <button
                      key={claim.id}
                      onClick={() => setSelectedClaimId(claim.id)}
                      className={`w-full text-left bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition border-2 ${
                        selectedClaimId === claim.id ? 'border-green-500' : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">{claim.id}</span>
                        <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${getStatusColor(claim.currentState)}`}>
                          {getStatusIcon(claim.currentState)}
                          {claim.currentState.replace('_', ' ')}
                        </div>
                      </div>
                      <p className="mb-1">{claim.cropType}</p>
                      <p className="text-sm text-gray-600">{claim.incidentType}</p>
                    </button>
                  ))}
                </div>

                <div className="lg:col-span-2">
                  {selectedClaim && (
                    <div className="space-y-6">
                      <ClaimTimeline claim={selectedClaim} />
                      {selectedClaim.aiEvidence && (
                        <AIEvidencePanel
                          claim={selectedClaim}
                          evidence={selectedClaim.aiEvidence}
                        />
                      )}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
