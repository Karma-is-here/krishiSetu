import { useState } from 'react';
import { Leaf, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface FarmerLoginProps {
  onLoginComplete: () => void;
}

export default function FarmerLogin({ onLoginComplete }: FarmerLoginProps) {
  const { t } = useLanguage();
  const [step, setStep] = useState<'mobile' | 'otp'>('mobile');
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');

  const handleSendOTP = () => {
    if (mobile.length === 10) {
      setStep('otp');
    }
  };

  const handleVerifyOTP = () => {
    if (otp.length === 4) {
      onLoginComplete();
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-green-50 to-green-100">
      <div className="max-w-md w-full mx-auto px-6">
        <div className="bg-white p-8 rounded-xl shadow-lg">
          <div className="flex items-center justify-center mb-6">
            <Leaf className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-2xl text-center mb-8">{t('farmer_login')}</h1>

          {step === 'mobile' && (
            <div className="space-y-6">
              <div>
                <label className="block mb-2 text-sm">{t('enter_mobile')}</label>
                <input
                  type="tel"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  placeholder="10-digit mobile number"
                  className="w-full p-3 border-2 border-gray-300 rounded-lg text-lg focus:border-green-600 focus:outline-none"
                  maxLength={10}
                />
              </div>
              <button
                onClick={handleSendOTP}
                disabled={mobile.length !== 10}
                className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed text-lg"
              >
                {t('send_otp')}
              </button>
            </div>
          )}

          {step === 'otp' && (
            <div className="space-y-6">
              <button
                onClick={() => setStep('mobile')}
                className="flex items-center gap-2 text-green-700 hover:underline mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                Change number
              </button>
              <div>
                <label className="block mb-2 text-sm">{t('enter_otp')}</label>
                <p className="text-sm text-gray-600 mb-3">
                  OTP sent to +91 {mobile}
                </p>
                <input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="4-digit OTP"
                  className="w-full p-3 border-2 border-gray-300 rounded-lg text-lg tracking-widest text-center focus:border-green-600 focus:outline-none"
                  maxLength={4}
                />
                <p className="text-xs text-gray-500 mt-2">
                  For demo, enter any 4 digits
                </p>
              </div>
              <button
                onClick={handleVerifyOTP}
                disabled={otp.length !== 4}
                className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed text-lg"
              >
                {t('verify')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
