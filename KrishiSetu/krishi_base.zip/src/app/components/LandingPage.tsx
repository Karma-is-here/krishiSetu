import { Leaf, FileText, TrendingUp, Eye } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface LandingPageProps {
  onFarmerLogin: () => void;
  onAuthorityLogin: () => void;
}

export default function LandingPage({ onFarmerLogin, onAuthorityLogin }: LandingPageProps) {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="size-full overflow-y-auto bg-gradient-to-br from-green-50 to-green-100">
      {/* Header */}
      <header className="bg-green-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Leaf className="w-8 h-8" />
            <h1 className="text-xl">{t('system_title')}</h1>
          </div>
          <nav className="flex items-center gap-6">
            <div className="flex items-center gap-2 bg-green-800 rounded-lg px-3 py-2">
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded transition ${
                  language === 'en' ? 'bg-white text-green-700' : 'text-white hover:bg-green-700'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-3 py-1 rounded transition ${
                  language === 'hi' ? 'bg-white text-green-700' : 'text-white hover:bg-green-700'
                }`}
              >
                हिंदी
              </button>
            </div>
            <a href="#about" className="hover:underline">{t('about')}</a>
            <a href="#how-it-works" className="hover:underline">{t('how_it_works')}</a>
            <a href="#policies" className="hover:underline">{t('policies')}</a>
            <a href="#claims" className="hover:underline">{t('claims')}</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-green-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl mb-4">{t('hero_title')}</h2>
          <p className="text-xl mb-8 opacity-90">
            {t('hero_subtitle')}
          </p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={onFarmerLogin}
              className="bg-white text-green-700 px-8 py-3 rounded-lg hover:bg-green-50 transition text-lg"
            >
              {t('farmer_login')}
            </button>
            <button
              onClick={onAuthorityLogin}
              className="bg-green-700 text-white px-8 py-3 rounded-lg border-2 border-white hover:bg-green-800 transition text-lg"
            >
              {t('authority_login')}
            </button>
          </div>
        </div>
      </section>

      {/* Info Cards */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
            <FileText className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-lg mb-2">{t('submit_claim')}</h3>
            <p className="text-gray-600 text-sm">
              {language === 'en'
                ? 'Easily submit agricultural insurance claims with minimal inputs'
                : 'न्यूनतम इनपुट के साथ आसानी से कृषि बीमा दावे जमा करें'}
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
            <TrendingUp className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-lg mb-2">{t('track_claim')}</h3>
            <p className="text-gray-600 text-sm">
              {language === 'en'
                ? 'Real-time tracking with full transparency of validation process'
                : 'सत्यापन प्रक्रिया की पूर्ण पारदर्शिता के साथ वास्तविक समय ट्रैकिंग'}
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
            <Leaf className="w-12 h-12 text-amber-600 mb-4" />
            <h3 className="text-lg mb-2">{t('policy_rules')}</h3>
            <p className="text-gray-600 text-sm">
              {language === 'en'
                ? 'Democratic governance with multi-authority voting system'
                : 'बहु-प्राधिकरण मतदान प्रणाली के साथ लोकतांत्रिक शासन'}
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
            <Eye className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-lg mb-2">{t('transparency_dashboard')}</h3>
            <p className="text-gray-600 text-sm">
              {language === 'en'
                ? 'Every decision explained with AI-powered insights'
                : 'एआई-संचालित अंतर्दृष्टि के साथ हर निर्णय की व्याख्या'}
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="mb-3">
                {language === 'en' ? 'Government Affiliations' : 'सरकारी संबद्धता'}
              </h4>
              <p className="text-green-200">
                {language === 'en'
                  ? 'Ministry of Agriculture & Farmers Welfare'
                  : 'कृषि और किसान कल्याण मंत्रालय'}
              </p>
              <p className="text-green-200">
                {language === 'en' ? 'State Agricultural Departments' : 'राज्य कृषि विभाग'}
              </p>
            </div>
            <div>
              <h4 className="mb-3">{language === 'en' ? 'Contact' : 'संपर्क'}</h4>
              <p className="text-green-200">Email: support@agri-claim.gov.in</p>
              <p className="text-green-200">Toll Free: 1800-XXX-XXXX</p>
            </div>
            <div>
              <h4 className="mb-3">{language === 'en' ? 'Quick Links' : 'त्वरित लिंक'}</h4>
              <p className="text-green-200">{language === 'en' ? 'FAQs' : 'सामान्य प्रश्न'}</p>
              <p className="text-green-200">{language === 'en' ? 'Guidelines' : 'दिशानिर्देश'}</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
