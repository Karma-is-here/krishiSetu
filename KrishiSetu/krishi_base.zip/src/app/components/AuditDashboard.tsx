import { useState } from 'react';
import { LogOut, Eye, CheckCircle, XCircle } from 'lucide-react';
import { useClaims } from '../context/ClaimContext';
import ClaimTimeline from './ClaimTimeline';

interface DashboardProps {
  onLogout: () => void;
}

export default function AuditDashboard({ onLogout }: DashboardProps) {
  const { claims } = useClaims();
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);

  const selectedClaim = selectedClaimId
    ? claims.find((c) => c.id === selectedClaimId)
    : null;

  return (
    <div className="size-full flex flex-col bg-gray-50">
      <header className="bg-amber-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl">Audit Authority Dashboard</h1>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-amber-800 px-4 py-2 rounded-lg hover:bg-amber-900 transition"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="bg-amber-50 border-l-4 border-amber-600 p-4 mb-8 rounded">
            <p className="text-sm">
              <strong>Role:</strong> Oversight and transparency - View-only access to complete claim history
            </p>
            <p className="text-sm mt-2">
              <strong>Visibility:</strong> Full access to all claims and state transitions (read-only)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Total Claims</h3>
              <p className="text-3xl text-amber-600">{claims.length}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Approved</h3>
              <p className="text-3xl text-green-600">
                {claims.filter((c) => ['APPROVED', 'PAID', 'PAYOUT_PENDING'].includes(c.currentState)).length}
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">Rejected</h3>
              <p className="text-3xl text-red-600">
                {claims.filter((c) => c.currentState === 'REJECTED').length}
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-sm text-gray-600 mb-2">In Progress</h3>
              <p className="text-3xl text-blue-600">
                {
                  claims.filter((c) =>
                    ['SUBMITTED', 'AI_ANALYZED', 'UNDER_REVIEW', 'ENDORSED', 'ESCALATED'].includes(
                      c.currentState
                    )
                  ).length
                }
              </p>
            </div>
          </div>

          <h2 className="text-2xl mb-6">Complete Claim Audit Trail</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              {claims.map((claim) => (
                <button
                  key={claim.id}
                  onClick={() => setSelectedClaimId(claim.id)}
                  className={`w-full text-left bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition border-2 ${
                    selectedClaimId === claim.id ? 'border-amber-500' : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">{claim.id}</span>
                    {['APPROVED', 'PAID'].includes(claim.currentState) ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : claim.currentState === 'REJECTED' ? (
                      <XCircle className="w-5 h-5 text-red-600" />
                    ) : null}
                  </div>
                  <p className="mb-1">{claim.cropType}</p>
                  <p className="text-sm text-gray-600 mb-2">Farmer: {claim.farmerName}</p>
                  <p className="text-xs text-amber-700">
                    State Transitions: {claim.stateHistory.length}
                  </p>
                </button>
              ))}
            </div>

            <div className="lg:col-span-2">
              {selectedClaim ? (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-lg mb-4">Claim Overview</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Claim ID</p>
                        <p>{selectedClaim.id}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Farmer</p>
                        <p>{selectedClaim.farmerName}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Crop Type</p>
                        <p>{selectedClaim.cropType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Current Status</p>
                        <p className="capitalize">{selectedClaim.currentState.replace('_', ' ')}</p>
                      </div>
                    </div>
                  </div>

                  <ClaimTimeline claim={selectedClaim} />

                  <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-lg mb-4 flex items-center gap-2">
                      <Eye className="w-5 h-5 text-amber-600" />
                      Complete State History
                    </h3>
                    <div className="space-y-3">
                      {selectedClaim.stateHistory.map((history, idx) => (
                        <div
                          key={idx}
                          className="border-l-4 border-amber-400 pl-4 py-2 bg-amber-50 rounded-r"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-sm">
                              <span className="font-mono text-xs text-gray-600">
                                {history.from}
                              </span>
                              {' → '}
                              <span className="font-mono text-xs text-gray-600">{history.to}</span>
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(history.timestamp).toLocaleString()}
                            </p>
                          </div>
                          <p className="text-xs text-gray-600">Actor: {history.actor}</p>
                          {history.reason && (
                            <p className="text-xs text-gray-700 mt-1">{history.reason}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-600">
                    <p className="text-sm">
                      <strong>Immutability Guarantee:</strong>
                    </p>
                    <p className="text-sm text-blue-800 mt-1">
                      All state transitions are recorded on the blockchain. Hash:{' '}
                      <span className="font-mono text-xs">{selectedClaim.blockchainHash}</span>
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-white p-12 rounded-lg shadow-md text-center text-gray-500">
                  <Eye className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p>Select a claim to view complete audit trail</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
