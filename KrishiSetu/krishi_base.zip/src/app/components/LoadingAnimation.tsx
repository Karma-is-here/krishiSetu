import { Satellite, CloudRain, Sprout } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function LoadingAnimation() {
  const { t } = useLanguage();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-12 rounded-xl shadow-2xl max-w-md w-full mx-4">
        <div className="text-center">
          <div className="flex justify-center gap-4 mb-8">
            <div className="animate-bounce" style={{ animationDelay: '0ms' }}>
              <Satellite className="w-12 h-12 text-blue-600" />
            </div>
            <div className="animate-bounce" style={{ animationDelay: '150ms' }}>
              <CloudRain className="w-12 h-12 text-blue-500" />
            </div>
            <div className="animate-bounce" style={{ animationDelay: '300ms' }}>
              <Sprout className="w-12 h-12 text-green-600" />
            </div>
          </div>
          <h3 className="text-xl mb-4">{t('analyzing_data')}</h3>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <div className="bg-green-600 h-2 rounded-full animate-pulse" style={{ width: '70%' }}></div>
          </div>
          <p className="text-sm text-gray-600">
            Processing satellite imagery, rainfall data, and soil conditions...
          </p>
        </div>
      </div>
    </div>
  );
}
