import { useState } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { ClaimProvider } from './context/ClaimContext';
import LandingPage from './components/LandingPage';
import FarmerLogin from './components/FarmerLogin';
import AuthorityLogin from './components/AuthorityLogin';
import FarmerDashboard from './components/FarmerDashboard';
import InsuranceDashboard from './components/InsuranceDashboard';
import StateDashboard from './components/StateDashboard';
import CentralDashboard from './components/CentralDashboard';
import AuditDashboard from './components/AuditDashboard';
import BankDashboard from './components/BankDashboard';

export type UserRole = 'farmer' | 'insurance' | 'state' | 'central' | 'audit' | 'bank' | null;

export default function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'farmer-login' | 'authority-login' | 'dashboard'>('landing');
  const [userRole, setUserRole] = useState<UserRole>(null);

  const handleFarmerLogin = () => {
    setCurrentPage('farmer-login');
  };

  const handleAuthorityLogin = () => {
    setCurrentPage('authority-login');
  };

  const handleFarmerLoginComplete = () => {
    setUserRole('farmer');
    setCurrentPage('dashboard');
  };

  const handleAuthorityLoginComplete = (role: Exclude<UserRole, 'farmer' | null>) => {
    setUserRole(role);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentPage('landing');
  };

  return (
    <LanguageProvider>
      <ClaimProvider>
        <div className="size-full bg-gray-50">
          {currentPage === 'landing' && (
            <LandingPage
              onFarmerLogin={handleFarmerLogin}
              onAuthorityLogin={handleAuthorityLogin}
            />
          )}
          {currentPage === 'farmer-login' && (
            <FarmerLogin onLoginComplete={handleFarmerLoginComplete} />
          )}
          {currentPage === 'authority-login' && (
            <AuthorityLogin onLoginComplete={handleAuthorityLoginComplete} />
          )}
          {currentPage === 'dashboard' && userRole === 'farmer' && <FarmerDashboard onLogout={handleLogout} />}
          {currentPage === 'dashboard' && userRole === 'insurance' && <InsuranceDashboard onLogout={handleLogout} />}
          {currentPage === 'dashboard' && userRole === 'state' && <StateDashboard onLogout={handleLogout} />}
          {currentPage === 'dashboard' && userRole === 'central' && <CentralDashboard onLogout={handleLogout} />}
          {currentPage === 'dashboard' && userRole === 'audit' && <AuditDashboard onLogout={handleLogout} />}
          {currentPage === 'dashboard' && userRole === 'bank' && <BankDashboard onLogout={handleLogout} />}
        </div>
      </ClaimProvider>
    </LanguageProvider>
  );
}
