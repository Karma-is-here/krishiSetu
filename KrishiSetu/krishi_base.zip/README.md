
  # User request

  This is a code bundle for User request. The original project is available at https://www.figma.com/design/E6HHcq5w6fAUPAwHm07lmZ/User-request.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  